let current = 1;
const total = 6;

function showPage(n) {
  current = Math.max(1, Math.min(total, n));
  document.querySelectorAll('.page').forEach((p,i) => p.classList.toggle('active', i === current-1));
  document.querySelectorAll('.dot').forEach((d,i) => d.classList.toggle('active-dot', i === current-1));
  window.scrollTo({top:0, behavior:'smooth'});
}

function nextPage(){ showPage(current + 1); }

document.addEventListener('keydown', e => {
  if(e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); nextPage(); }
  if(e.key === 'ArrowLeft') showPage(current - 1);
});

function makeHeart(){
  const h=document.createElement('div');
  h.className='heart';
  h.textContent=['♥','♡','💗','💖','✨'][Math.floor(Math.random()*5)];
  h.style.left=Math.random()*100+'vw';
  h.style.animationDuration=(5+Math.random()*5)+'s';
  h.style.fontSize=(12+Math.random()*18)+'px';
  document.querySelector('.hearts').appendChild(h);
  setTimeout(()=>h.remove(),10000);
}
setInterval(makeHeart,650);
